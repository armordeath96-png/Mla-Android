package com.mla.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import kotlin.random.Random

private val Bg = Color(0xFF090D18)
private val Panel = Color(0xFF151D2D)
private val Gold = Color(0xFFD9A62E)
private val Red = Color(0xFFE53945)
private data class Hero(val id:String,val name:String,val faction:String,val rarity:String)
private data class Banner(val id:String,val name:String,val special:String,val heroes:List<Hero>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MlaApp() }
    }
}

@Composable
private fun MlaApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mla_save", 0) }
    val banners = remember {
        val raw = context.assets.open("heroes.json").bufferedReader().use { it.readText() }
        val root = JSONObject(raw)
        val arr = root.getJSONArray("banners")
        (0 until arr.length()).map { i ->
            val b = arr.getJSONObject(i); val hs = b.getJSONArray("heroes")
            Banner(b.getString("id"), b.getString("name"), b.optString("special"),
                (0 until hs.length()).map { j -> val h=hs.getJSONObject(j); Hero(h.getString("id"),h.getString("name"),h.getString("faction"),h.getString("rarity")) })
        }
    }
    var selected by remember { mutableIntStateOf(0) }
    var tab by remember { mutableStateOf("Призыв") }
    var results by remember { mutableStateOf(listOf<Hero>()) }
    var status by remember { mutableStateOf("Выбери баннер и сделай призыв") }
    var total by remember { mutableIntStateOf(prefs.getInt("total",0)) }
    var ssrPity by remember { mutableIntStateOf(prefs.getInt("ssr_${banners[0].id}",0)) }
    var urPity by remember { mutableIntStateOf(prefs.getInt("ur_oath",0)) }
    var inventory by remember { mutableStateOf(prefs.getStringSet("inventory", emptySet())!!.toSet()) }
    val banner = banners[selected]

    fun pityKey() = "ssr_${banner.id}"
    fun summon(count:Int) {
        val pulled = mutableListOf<Hero>()
        repeat(count) {
            val pool = banner.heroes
            val r = Random.nextDouble(100.0)
            val rarity = when (banner.special) {
                "oath" -> if (r < 2.0 || urPity >= 49) "UR" else if (r < 6.5) "SSR" else "SR"
                else -> if (r < 4.61 || ssrPity >= (if (banner.special=="sacred") 49 else 29)) "SSR" else if (r < 48.31) "SR" else "R"
            }
            val candidates = pool.filter { it.rarity == rarity }
            val chosen = candidates.randomOrNull() ?: pool.random()
            pulled.add(chosen)
            if (rarity == "SSR") ssrPity=0 else if (banner.special!="oath") ssrPity++
            if (rarity == "UR") urPity=0 else if (banner.special=="oath") urPity++
            total++
            inventory = inventory + chosen.id
        }
        results=pulled
        status="Призывов всего: $total"
        prefs.edit().putInt("total",total).putInt(pityKey(),ssrPity).putInt("ssr_${banner.id}",ssrPity).putInt("ur_oath",urPity).putStringSet("inventory",inventory).apply()
    }

    MaterialTheme(colorScheme = darkColorScheme(background=Bg,surface=Panel,primary=Gold,onBackground=Color.White,onSurface=Color.White)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
            Text("MLA: game",fontSize=27.sp,fontWeight=FontWeight.ExtraBold,color=Gold)
            Text("Мобильный симулятор призыва",fontSize=12.sp,color=Color.LightGray)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                listOf("Призыв","Коллекция","Статистика").forEach { label ->
                    FilterChip(selected=tab==label,onClick={tab=label},label={Text(label)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Gold,selectedLabelColor=Bg))
                }
            }
            Spacer(Modifier.height(12.dp))
            when(tab) {
                "Призыв" -> {
                    Text("БАННЕРЫ",fontSize=12.sp,color=Gold,fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    banners.forEachIndexed { index,b ->
                        Card(onClick={selected=index;ssrPity=prefs.getInt("ssr_${b.id}",0);results= emptyList()},modifier=Modifier.fillMaxWidth().padding(vertical=3.dp),colors=CardDefaults.cardColors(containerColor=if(selected==index) Color(0xFF29364C) else Panel),shape=RoundedCornerShape(12.dp)) {
                            Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically) {
                                Text(b.name,Modifier.weight(1f),fontWeight=FontWeight.SemiBold)
                                if(selected==index) Text("ВЫБРАН",color=Gold,fontSize=10.sp,fontWeight=FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Card(colors=CardDefaults.cardColors(containerColor=Panel),modifier=Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(banner.name,fontSize=18.sp,fontWeight=FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            if(banner.special=="oath") {
                                Text("Гарант UR: $urPity / 50",color=Red,fontWeight=FontWeight.Bold)
                            } else {
                                val limit=if(banner.special=="sacred") 50 else 30
                                Text("Гарант SSR: $ssrPity / $limit",color=Gold,fontWeight=FontWeight.Bold)
                            }
                            Text("Все счётчики сохраняются на устройстве",fontSize=11.sp,color=Color.LightGray)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        Button(onClick={summon(1)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Bg)) { Text("ПРИЗЫВ ×1",fontWeight=FontWeight.Bold) }
                        Button(onClick={summon(10)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Red)) { Text("ПРИЗЫВ ×10",fontWeight=FontWeight.Bold) }
                    }
                    Text(status,color=Color.LightGray,fontSize=12.sp,modifier=Modifier.padding(top=10.dp))
                    if(results.isNotEmpty()) {
                        Text("РЕЗУЛЬТАТ",color=Gold,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp,bottom=6.dp))
                        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                            items(results) { h -> HeroRow(h) }
                        }
                    } else Spacer(Modifier.weight(1f))
                }
                "Коллекция" -> {
                    Text("СОБРАНО: ${inventory.size} / 167",color=Gold,fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    val all=banners.first().heroes.distinctBy{it.id}
                    LazyColumn(verticalArrangement=Arrangement.spacedBy(5.dp)) {
                        items(all.filter{inventory.contains(it.id)}) { HeroRow(it) }
                    }
                }
                else -> {
                    Text("СТАТИСТИКА",color=Gold,fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Text("Всего призывов: $total",fontSize=18.sp)
                    Text("Получено уникальных героев: ${inventory.size}",fontSize=16.sp)
                    Spacer(Modifier.height(18.dp))
                    OutlinedButton(onClick={ total=0;ssrPity=0;urPity=0;inventory= emptySet();results= emptyList();prefs.edit().clear().apply() }) { Text("СБРОСИТЬ ПРОГРЕСС",color=Red) }
                }
            }
        }
    }
}

@Composable
private fun HeroRow(hero:Hero) {
    val color=when(hero.rarity){"UR"->Red;"SSR"->Gold;"SR"->Color(0xFF159BC4);else->Color(0xFF16A36A)}
    Card(colors=CardDefaults.cardColors(containerColor=Panel),modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(10.dp)) {
        Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(color,RoundedCornerShape(50)))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(hero.name,fontWeight=FontWeight.SemiBold);Text(hero.faction,fontSize=11.sp,color=Color.LightGray) }
            Text(hero.rarity,color=color,fontWeight=FontWeight.Bold)
        }
    }
}
